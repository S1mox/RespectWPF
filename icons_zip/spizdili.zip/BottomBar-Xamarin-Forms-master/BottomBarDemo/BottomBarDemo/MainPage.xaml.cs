﻿using BottomBar.XamarinForms;

namespace BottomBarDemo
{
    public partial class MainPage : BottomBarPage
    {
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
